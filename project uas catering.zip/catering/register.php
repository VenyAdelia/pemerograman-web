<?php
include "inc/config.php";

if (!empty($_SESSION['iam_user'])) {
    redir("index.php");
}

include "layout/header.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $telephone = trim($_POST['telephone']);
    $alamat = trim($_POST['alamat']);
    $password = $_POST['password'];

    // Validasi sederhana
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<div class="alert alert-danger">Email tidak valid.</div>';
    } elseif (strlen($password) < 6) {
        echo '<div class="alert alert-danger">Password minimal 6 karakter.</div>';
    } else {
        // Hash password dengan md5 (jika memang harus, walau lebih baik password_hash)
        $password_hash = md5($password);

        // Cek apakah email sudah terdaftar
        $cek = $koneksi->prepare("SELECT id FROM user WHERE email = ?");
        $cek->bind_param("s", $email);
        $cek->execute();
        $cek->store_result();

        if ($cek->num_rows > 0) {
            echo '<div class="alert alert-danger">Email sudah terdaftar.</div>';
        } else {
            // Simpan data
            $stmt = $koneksi->prepare("INSERT INTO user (nama, email, telephone, alamat, password, status) VALUES (?, ?, ?, ?, ?, 'user')");
            $stmt->bind_param("sssss", $nama, $email, $telephone, $alamat, $password_hash);

            if ($stmt->execute()) {
                echo '<div class="alert alert-success">Registrasi berhasil. <a href="login.php">Silahkan login</a>.</div>';
            } else {
                echo '<div class="alert alert-danger">Terjadi kesalahan. Silakan coba lagi.</div>';
            }
            $stmt->close();
        }
        $cek->close();
    }
}
?>

<!-- Styling -->
<style>
body {
    background-color: #f5f7fa;
    font-family: 'Segoe UI', sans-serif;
}
h3 {
    margin-top: 30px;
    font-weight: 600;
    color: #333;
}
.content-menu {
    background: #ffffff;
    padding: 24px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
input.form-control {
    height: 42px;
    font-size: 14px;
    border-radius: 6px;
    border: 1px solid #ced4da;
    margin-bottom: 16px;
}
input.form-control:focus {
    border-color: #66afe9;
    box-shadow: none;
    outline: none;
}
.btn-success {
    background-color: #28a745;
    border-color: #28a745;
    font-weight: 500;
    padding: 10px;
    font-size: 14px;
    border-radius: 6px;
    transition: background 0.2s ease;
}
.btn-success:hover {
    background-color: #218838;
    border-color: #1e7e34;
}
.col-md-9 {
    margin: 0 auto;
    margin-top: 50px;
}
a {
    color: #007bff;
    text-decoration: none;
}
a:hover {
    text-decoration: underline;
}
</style>

<!-- Tampilan Register -->
<div class="col-md-9">
    <div class="row">
        <div class="col-md-12">
            <h3>Register User</h3>
            <hr>
            <div class="col-md-7 content-menu" style="margin-top:-20px;">
                <form action="" method="post" enctype="multipart/form-data">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama" required placeholder="Masukkan Nama">
                    
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" required placeholder="Masukkan Email">
                    
                    <label>Telephone</label>
                    <input type="text" class="form-control" name="telephone" required placeholder="Masukkan Nomor Telp">
                    
                    <label>Alamat</label>
                    <input type="text" class="form-control" name="alamat" required placeholder="Masukkan Alamat">
                    
                    <label>Password</label>
                    <input type="password" class="form-control" name="password" required placeholder="Masukkan Password">
                    
                    <input type="submit" name="form-input" value="Register" class="btn btn-success">
                </form>
            </div>

            <!-- TANPA background putih -->
            <div class="col-md-12 text-center" style="margin-top: 20px; font-size: 14px;">
                Sudah punya akun? <a href="login.php">Login Sekarang!</a>
            </div>
        </div>
    </div>
</div>

<?php include "layout/footer.php"; ?>
