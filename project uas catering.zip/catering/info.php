<?php
	include "inc/config.php"; 
	include "layout/header.php";	
?>

<div class="col-md-9">
	<div class="row">
		<?php
			
			$q = mysqli_query($koneksi, "SELECT * FROM info_pembayaran LIMIT 1");

			// Cek jika query gagal
			if (!$q) {
				die("Query error: " . mysqli_error($koneksi));
			}

			
			$data = mysqli_fetch_object($q);
		?>

		<!-- Tampilkan data -->
		<div  style="font-family: Arial, sans-serif; font-size: 16px; color: #333; line-height: 1.6; background: #f9f9f9; padding: 15px; border-left: 5px solid #3498db; border-radius: 8px;"    class="info-pembayaran">
  <?php echo $data ? nl2br(htmlspecialchars($data->info)) : 'Belum ada informasi pembayaran.'; ?>
</div>

</div>

<?php
	include "layout/footer.php";
?>
