-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2025 at 12:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `catering`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail_pesanan`
--

CREATE TABLE `detail_pesanan` (
  `id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `pesanan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `detail_pesanan`
--

INSERT INTO `detail_pesanan` (`id`, `produk_id`, `qty`, `pesanan_id`) VALUES
(24, 2, 20, 28),
(25, 12, 20, 28),
(27, 2, 20, 30),
(28, 1, 20, 31),
(29, 1, 40, 32),
(32, 9, 40, 38),
(33, 4, 40, 39),
(34, 2, 40, 39),
(35, 1, 45, 40),
(36, 1, 40, 41);

-- --------------------------------------------------------

--
-- Table structure for table `info_pembayaran`
--

CREATE TABLE `info_pembayaran` (
  `id` int(11) NOT NULL,
  `info` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `info_pembayaran`
--

INSERT INTO `info_pembayaran` (`id`, `info`) VALUES
(1, 'Untuk melanjutkan pesanan, pembayaran dapat dilakukan terlebih dahulu sebesar 50% (DP) sebelum hari-H acara.\r\nApabila tidak ada pembayaran hingga batas waktu yang ditentukan, maka transaksi akan otomatis dibatalkan.\r\nSilakan lakukan pembayaran ke rekening berikut:\r\nBank BRI  \r\nNo. Rekening: 6601 9283 9102 938  \r\nv.n. Veny / Nita\r\nSetelah melakukan pembayaran, harap segera melakukan konfirmasi melalui menu \"Pembayaran\".\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_produk`
--

CREATE TABLE `kategori_produk` (
  `id` int(3) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kategori_produk`
--

INSERT INTO `kategori_produk` (`id`, `nama`, `deskripsi`) VALUES
(6, 'Pastry', ''),
(7, 'Steak', ''),
(8, 'Drinks', ''),
(9, 'main course', '');

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE `kontak` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subjek` varchar(200) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kontak`
--

INSERT INTO `kontak` (`id`, `nama`, `email`, `subjek`, `pesan`) VALUES
(23, 'yuyunni', 'yuyuni@gmail.com', 'makanan', 'cepat ya pengirimannya\r\n'),
(24, 'nii', 'nii@gmail.com', 'baikk', 'plynnannya cpt');

-- --------------------------------------------------------

--
-- Table structure for table `kota`
--

CREATE TABLE `kota` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `ongkir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `kota`
--

INSERT INTO `kota` (`id`, `nama`, `ongkir`) VALUES
(6, 'jakarta', 20000),
(7, 'bekasi', 35000),
(8, 'tanggerang', 49000),
(9, 'bogor', 32000),
(10, 'depok', 36000);

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

CREATE TABLE `laporan` (
  `id_pengeluaran` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `Tanggal_pengeluaran` date NOT NULL,
  `harga` varchar(10) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`id_pengeluaran`, `nama_barang`, `Tanggal_pengeluaran`, `harga`, `jumlah`, `total`) VALUES
(40, 'beras', '2025-06-24', '50000', 8, 400000),
(42, 'gas', '2025-06-24', '22000', 6, 132000),
(43, 'daging ayam', '2025-06-24', '30000', 7, 210000);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `id_pesanan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `total` int(11) NOT NULL,
  `status` enum('pending','verified','','') NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `id_pesanan`, `id_user`, `file`, `total`, `status`, `keterangan`, `created_at`) VALUES
(11, 27, 9, '39fe6f5363af164c2f49e60ac67caa61.jpg', 660, 'verified', 'bank bri', '2025-06-24 08:21:00'),
(12, 27, 9, '0469166a0ca056a60f91bb4fa12ea76d.jpg', 660, 'verified', 'bank bri', '2025-06-24 08:21:43'),
(13, 28, 9, '550f19daa60accaad2c784a4ec0044eb.jpg', 860000, 'verified', 'bank bni', '2025-06-24 08:24:35'),
(14, 30, 9, '2fd55a97cb1a358e3c499f216f74208e.png', 160000, 'verified', 'bank bni', '2025-06-24 08:50:04'),
(15, 31, 10, 'afc6d73ba9357bc31ed6b55a063c4977.png', 1020000, 'verified', 'bank bri', '2025-06-26 01:18:50'),
(16, 32, 9, 'bf3d1403e1ddf588617cdb11d3abfe29.png', 2000000, 'verified', 'bnk bri', '2025-06-26 03:50:24'),
(17, 38, 9, '64cae3377a1f5b8d2081b2dbbef924dc.png', 1040000, 'verified', 'bnk mndiri', '2025-06-26 08:23:20'),
(18, 39, 9, '0044a0ad3f11ebc8b5b66fcba6f08a61.jpg', 2080000, 'verified', 'bnk bri', '2025-06-27 02:34:46'),
(19, 40, 9, '710a72bf8e9db99d9388d60a4bc53ad5.jpg', 2255000, 'verified', 'bnk btn', '2025-06-27 02:47:12'),
(20, 41, 9, '8e3f94c9e08c7b820828253d56182dd5.png', 2000000, 'verified', 'bnk bri', '2025-07-01 07:02:41');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(5) NOT NULL,
  `tanggal_pesan` datetime NOT NULL,
  `tanggal_digunakan` datetime NOT NULL,
  `user_id` int(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(255) NOT NULL,
  `ongkir` int(11) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `read` tinyint(1) NOT NULL,
  `status` enum('lunas','belum lunas','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id`, `tanggal_pesan`, `tanggal_digunakan`, `user_id`, `nama`, `alamat`, `kota`, `ongkir`, `telephone`, `read`, `status`) VALUES
(28, '2025-06-24 17:24:01', '2025-06-29 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas'),
(30, '2025-06-24 00:00:00', '2025-06-28 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas'),
(31, '2025-06-26 10:18:03', '2025-06-29 00:00:00', 10, 'ninik', 'bandung', 'Semarang', 40000, '08976457897', 1, 'lunas'),
(32, '2025-06-26 12:50:00', '2025-06-29 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas'),
(38, '2025-06-26 17:22:47', '2025-07-01 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas'),
(39, '2025-06-27 11:34:05', '2025-07-02 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas'),
(40, '2025-06-27 00:00:00', '2025-07-01 00:00:00', 9, 'yuyunni', 'kalimantan', 'kalimantan', 50000, '081270275432', 1, 'lunas'),
(41, '2025-07-01 16:02:03', '2025-07-05 00:00:00', 9, 'yuyunni', 'kalimantan', 'Semarang', 40000, '081270275432', 1, 'lunas');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(4) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` varchar(200) NOT NULL,
  `harga` decimal(10,0) NOT NULL,
  `kategori_produk_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama`, `deskripsi`, `gambar`, `harga`, `kategori_produk_id`) VALUES
(1, 'Steak kentang', 'Steak bisa dipadukan dengan kentang panggang yang diisi dengan berbagai topping seperti keju, krim asam, atau bacon.', '1374e386a0182914e5e056d4f94f39e1.jpg', 49000, 7),
(2, 'Teh Botol Sosro', 'minuman sehat menyegarkan', '5ad6b1e0a9c9baea01607906d1435e11.jpg', 6000, 8),
(3, 'nasi goreng seafood', 'Nasi goreng dengan cita rasa laut yang kaya, dimasak bersama udang, cumi, dan potongan bakso ikan segar. Dibumbui dengan racikan rempah khas yang gurih dan sedikit pedas, lalu ditumis sempurna hingga harum. Disajikan hangat dengan telur mata sapi, acar, dan kerupuk sebagai pelengkap. Cocok untuk pencinta seafood sejati!', '02fc3a00ee1900961a932a91de47aaf4.jpg', 26000, 9),
(4, 'Beef Steak', 'Steak daging sapi yang lembut dan kaya protein di olah dengan cara di grill / dipanggang. Disajikan dengan kentang lokal, mix vegetable, mushroom dan brown sauce khas waroeng.', 'b153dc510b67509870cb5ecb413397db.jpg', 45000, 7),
(8, 'espresso latte', 'Perpaduan sempurna antara espresso yang kuat dan susu yang lembut menciptakan minuman dengan rasa seimbang dan tekstur creamy. Cocok dinikmati kapan saja, memberikan energi sekaligus kenyamanan dalam setiap tegukan.\r\n\r\n', '9b8d24eaf876ea2b7a95608b9818c18e.jpg', 15000, 8),
(9, 'Roti Brioche', 'roti khas Prancis yang lembut dan kaya rasa, dibuat dengan campuran mentega, telur, dan susu. Teksturnya empuk dan sedikit manis, cocok dinikmati sebagai sarapan, camilan, atau pendamping kopi dan teh.', '332aa176a0bb6df3d95afe4aed2fae7d.jpg', 25000, 6),
(11, 'Black Pepper Sirloin', 'Sirloin steak empuk yang dipanggang hingga matang sempurna, disiram saus lada hitam khas yang gurih dan pedas. Dihidangkan dengan kentang goreng renyah dan sayuran segar sebagai pelengkap. Cocok untuk pecinta steak dengan cita rasa kuat dan beraroma menggoda.', '02a5bb25536cbb609ad3711075fbd4af.jpg', 45000, 7),
(12, 'Brown Sugar Boba', 'Air mineral murni dalam kemasan botol dari sumber pegunungan alami. Dikemas higienis, cocok untuk konsumsi harian, acara, atau stok usaha.\r\nIsi: 1 dus (24 botol @330ml)\r\nManfaat: Menjaga hidrasi tubuh, aman dan menyegarkan kapan saja.', '6b09a2b616f65a07f31216b7b3b74701.jpg', 35000, 8),
(13, 'cream puff ', 'Kue lembut bertekstur ringan dengan kulit luar yang renyah dan isi krim manis yang lembut di dalamnya. Cream puff hadir dengan rasa klasik yang memanjakan lidah, cocok sebagai camilan manis atau hidangan penutup di segala suasana.\r\n\r\n', 'e79239965e4de1ba851fbfdbfa1032db.jpeg', 20000, 6),
(14, 'nasi goreng spesial', 'Nasi goreng khas Indonesia yang dimasak dengan bumbu rempah pilihan, ditumis dengan telur, ayam suwir, dan sosis. Dihidangkan bersama acar, kerupuk, dan taburan bawang goreng. Cocok disantap kapan saja, dengan cita rasa gurih dan sedikit pedas yang menggugah selera.', '53606ccb9fa782dc058cf7eb3f6b061d.jpeg', 28000, 9),
(15, 'chiken teriyaki', 'Potongan daging ayam pilihan yang dimasak dengan saus teriyaki khas Jepang—manis, gurih, dan sedikit karamel. Disajikan dengan nasi putih hangat, taburan wijen, dan sayuran rebus sebagai pelengkap. Menu ini cocok untuk kamu yang suka rasa lembut dan beraroma oriental.', '78e3e93347a501581da25ec29b5853e9.jpg', 32000, 9),
(16, 'Thai Tea', 'Minuman teh khas Thailand yang menyegarkan, terbuat dari campuran teh hitam aromatik, susu kental manis, dan krimer. Memiliki rasa manis, creamy, dan aroma khas rempah ringan. Disajikan dingin dengan es batu, cocok dinikmati saat cuaca panas atau sebagai pelengkap makanan pedas.', '502af4477b3717a427f584e8cd88dc8a.jpeg', 20000, 8),
(17, 'nasi kuning', 'Nasi harum yang dimasak dengan santan dan kunyit, menghasilkan warna kuning keemasan serta cita rasa gurih khas nusantara. Disajikan dengan lauk pelengkap seperti ayam goreng, telur balado, sambal, orek tempe, dan serundeng kelapa. Cocok untuk sajian spesial, penuh rasa dan makna.\r\n\r\n', 'c1176fb029384006309eeb7614bfc310.jpeg', 25000, 9),
(18, 'Cheese Croissant', 'Croissant renyah berlapis-lapis dengan isian keju leleh di dalamnya. Dipanggang hingga keemasan, menghasilkan perpaduan rasa gurih dan buttery yang menggoda. Cocok dinikmati hangat sebagai camilan atau teman minum kopi.', '3438f86373f11b3b4d79d781274ad675.jpeg', 10000, 6),
(19, 'nasi briyani', 'Hidangan nasi khas Timur Tengah dan India yang dimasak dengan rempah-rempah aromatik seperti kapulaga, cengkeh, kayu manis, dan saffron. Disajikan dengan potongan ayam, kambing, atau daging sapi berbumbu kaya rasa. Nasi briyani memiliki aroma harum, rasa gurih pedas ringan, dan cocok dinikmati bersama acar dan saus yoghurt.', '2c7174ef9155019182bcd011c73b1290.jpg', 28000, 9),
(20, 'Brown Sugar Boba', 'Minuman kekinian yang memadukan susu segar dengan sirup gula aren khas dan boba kenyal yang manis. Disajikan dingin dengan tampilan bergradasi cantik, Brown Sugar Boba menghadirkan rasa lembut, legit, dan menyegarkan dalam setiap tegukan. Cocok dinikmati kapan saja!', '9dd914d56e9ef439bb9dece47a1cbfdc.jpg', 18000, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(75) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `alamat` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` enum('user','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `telephone`, `alamat`, `password`, `status`) VALUES
(5, 'ayu', 'ayunovita@gmail.com', '089688899260', 'Semarang ', 'fae38bd94701cdf2a9d114425cb40292', 'user'),
(7, 'yaya', 'yaya21@gmail.com', '081234532312', 'bandung', 'e88de1a7b50488958f5dbeeb52219be5', 'user'),
(8, 'alya', 'alyaa@gmail.com', '081267342243', 'sulawesi', '96a0dead881b8e2368157ccb08f76d74', 'user'),
(9, 'yuyunni', 'yuyuni@gmail.com', '081270275432', 'kalimantan', 'f5adde86d63550739747a6bd2a096470', 'user'),
(10, 'ninik', 'nini@gmail.com', '08976457897', 'bandung', 'cba366a51452da8b64f878875b7b9efe', 'user'),
(11, 'admin', 'admin@gmail.com', '09876557887', 'batam', '21232f297a57a5a743894a0e4a801fc3', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD PRIMARY KEY (`id`,`produk_id`,`pesanan_id`),
  ADD KEY `pesanan_id` (`pesanan_id`),
  ADD KEY `produk_id` (`produk_id`);

--
-- Indexes for table `info_pembayaran`
--
ALTER TABLE `info_pembayaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`id_pengeluaran`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`,`kategori_produk_id`),
  ADD KEY `kategori_produk_id` (`kategori_produk_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `info_pembayaran`
--
ALTER TABLE `info_pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `kota`
--
ALTER TABLE `kota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `laporan`
--
ALTER TABLE `laporan`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD CONSTRAINT `detail_pesanan_ibfk_2` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_pesanan_ibfk_3` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `pesanan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `produk_ibfk_1` FOREIGN KEY (`kategori_produk_id`) REFERENCES `kategori_produk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
