<?php global $koneksi; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="#">
  <title><?php echo $title; ?></title>

  <link href="<?php echo $url ?>assets/bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="<?php echo $url ?>assets/bootstrap/css/datetimepicker.css" rel="stylesheet">
  <link href="<?php echo $url ?>assets/css/navbar-fixed-top.css" rel="stylesheet">
  <link href="<?php echo $url ?>assets/css/full-slider.css" rel="stylesheet">
  <link href="<?php echo $url ?>assets/css/style.css" rel="stylesheet">

<style>
  .produk-img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  object-position: center;
  display: block;
}


  .produk-img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    object-position: center;
    display: block;
  }

  .navbar-blue {
    background-color:rgba(13, 30, 74, 0.99) !important;
    border: none !important;
  }

  .navbar-blue .navbar-brand,
  .navbar-blue .navbar-nav > li > a {
    color: #fff !important;
  }

  .navbar-blue .navbar-nav > li > a:hover {
    color: #222 !important;
    background-color:rgba(19, 42, 104, 0.86) !important;
  }


  .btn-info {
  background-color:rgb(116, 6, 78) !important;  /* pink */
  border-color:rgb(116, 6, 78) !important;
  color: white !important;
}

.btn-success {
  background-color:rgb(13, 47, 91) !important;  
  border-color: rgb(13, 47, 91)!important;
  color: white !important;
}

ul.kategori {
  list-style: none;
  padding: 0;
  margin: 0;
}

ul.kategori li {
  background-color: #f1f9ff;
  margin: 6px 0;
  border-radius: 6px;
  transition: all 0.3s ease;
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

ul.kategori li a {
  color: #0a4a78;
  font-weight: 500;
  text-decoration: none;
  display: block;
  padding: 10px 15px;
  border-radius: 6px;
}

ul.kategori li:hover {
  background-color: #d0eaff;
}

ul.kategori li a:hover {
  color: #00365c;
}

  
</style>


</head>

<body>

<nav class="navbar navbar-default navbar-fixed-top navbar-blue">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Catering Delita</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse"> 
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo $url ?>">Home</a></li>
        <li><a href="<?php echo $url ?>menu.php">Menu Katering</a></li> 
        <li><a href="<?php echo $url ?>kontak.php">Kontak Kami</a></li> 
        <li><a href="<?php echo $url ?>info.php">Info Pembayaran</a></li> 

        <?php if(!empty($_SESSION['iam_user'])){ 
          $user_query = mysqli_query($koneksi, "SELECT * FROM user WHERE id='$_SESSION[iam_user]'");
          $user = mysqli_fetch_object($user_query);
        ?>
        <li><a href="<?php echo $url ?>pembayaran.php">Pembayaran</a></li>      
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            Hi <?php echo $user->nama; ?> <span class="caret"></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo $url ?>profile.php">Profil</a></li> 
            <li><a href="<?php echo $url ?>logout.php">Logout</a></li>  
          </ul>
        </li>
        <?php } else { ?>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            Login/Register <span class="caret"></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo $url ?>login.php">Login</a></li> 
            <li><a href="<?php echo $url ?>register.php">Register</a></li>  
          </ul>
        </li>
        <?php } ?>
      </ul>
    </div>
  </div>
</nav>

<?php if('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'] == $url.'index.php'){ ?>
<div class="container">
  <header id="myCarousel" class="carousel slide">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li> 
    </ol>
    <div class="carousel-inner">
      <div class="item active">
        <div class="fill" style="background-image:url('<?php echo $url ?>assets/img/gambar1.jpg');"></div>
        <div class="carousel-caption">
          <h2>Selamat Berbelanja</h2>
        </div>
      </div>
      <div class="item">
        <div class="fill" style="background-image:url('<?php echo $url ?>assets/img/gambar2.jpg');"></div>
        <div class="carousel-caption">
          
        </div>
      </div> 
    </div>
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="icon-prev"></span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="icon-next"></span>
    </a>
  </header>
</div>
<?php } ?>

<div class="container" style="margin-top:20px;">
  <div class="row">
    <div class="col-md-3">
     <div style="background:rgb(34, 65, 143); color:white; width:100%; height:auto; padding-top:3px;padding-bottom:3px; padding-left:10px;">
        <h4>Kategori Menu</h4>
      </div>
      <ul class="kategori">
        <?php 
        $kategori = mysqli_query($koneksi, "SELECT * FROM kategori_produk");
        while($data = mysqli_fetch_array($kategori)){
        ?>
        <li>
          <a href="<?php echo $url; ?>menu.php?kategori=<?php echo $data['id'] ?>">
           🍽️ <?php echo $data['nama']; ?> (

            <?php 
              $ck_result = mysqli_query($koneksi, "SELECT * FROM produk WHERE kategori_produk_id='$data[id]'");
              $ck = mysqli_num_rows($ck_result);
              echo $ck > 0 ? $ck : 0;
            ?>)
          </a>
        </li>
        <?php } ?>
      </ul>

     <div style="background:#223f7a; color:white; padding:12px 15px; border-top-left-radius:8px; border-top-right-radius:8px;">
  <h4 style="margin:0; font-weight:600; font-size:17px;">
    🛒 Keranjang Belanja
  </h4>
</div>
<div style="background:#f9f9f9; padding:12px 15px; border:1px solid #ccc; border-top:none; border-bottom-left-radius:8px; border-bottom-right-radius:8px;">

        <?php
        if(isset($_SESSION['cart'])){
          $total = 0;
          $cart = unserialize($_SESSION['cart']);
          if($cart == '') $cart = [];
          foreach($cart as $id => $qty){
            $result = mysqli_query($koneksi, "SELECT * FROM produk WHERE id='$id'");
            $product = mysqli_fetch_array($result);
            if(isset($product)){
              $t = $qty * $product['harga'];
              $total += $t;
            }
          }
          echo '<h4 style="color:#f00;">Rp '. number_format($total, 2, ',', '.') .'</h4>';
        }else{
          echo '<h4 style="color:#f00;">Rp 0,00</h4>';
        }
        ?>
        <a href="<?php echo $url; ?>keranjang.php">Lihat Detail</a>
      </div>
      <div class="row col-md-12">
        <hr>
      </div>
    </div>
