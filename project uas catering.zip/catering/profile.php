<?php 
session_start();
include "inc/config.php";

if (empty($_SESSION['iam_user'])) {
    echo "<script>window.location='index.php';</script>";
    exit;
}

$user_id = $_SESSION['iam_user'];

// Ambil data user
$user_stmt = mysqli_prepare($koneksi, "SELECT * FROM user WHERE id = ?");
mysqli_stmt_bind_param($user_stmt, "i", $user_id);
mysqli_stmt_execute($user_stmt);
$user_result = mysqli_stmt_get_result($user_stmt);
$user = mysqli_fetch_object($user_result);

include "layout/header.php";

// Ambil data pesanan user
$pesanan_stmt = mysqli_prepare($koneksi, "SELECT * FROM pesanan WHERE user_id = ?");
mysqli_stmt_bind_param($pesanan_stmt, "i", $user_id);
mysqli_stmt_execute($pesanan_stmt);
$pesanan_result = mysqli_stmt_get_result($pesanan_stmt);

$no = 1;
?> 

<div class="col-md-9">
    <div class="row">
        <div class="col-md-12">
            <h3>Profile : <?php echo htmlspecialchars($user->nama); ?></h3>
            <hr>
            <div class="col-md-6 content-menu" style="margin-top:-20px;">
                <table class="table table-striped">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo htmlspecialchars($user->nama); ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><?php echo htmlspecialchars($user->email); ?></td>
                    </tr>
                    <tr>
                        <td>Telephone</td>
                        <td>:</td>
                        <td><?php echo htmlspecialchars($user->telephone); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td><?php echo htmlspecialchars($user->alamat); ?></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td>--- *** --</td>
                    </tr>
                </table>
            </div>

            <div class="col-md-12 content-menu">
                <h3>Riwayat Pemesanan</h3>
                <hr>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pemesan</th>
                            <th>Tanggal Pesan</th>
                            <th>Tanggal Digunakan</th>
                            <th>Telephone</th>
                            <th>Alamat</th>
                            <th>Status</th> <!-- Kolom baru -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($data = mysqli_fetch_object($pesanan_result)) { ?>
                            <tr <?php if ($data->read == 0) { echo 'style="background:#cce9f8 !important;"'; } ?>>
                                <th scope="row"><?php echo $no++; ?></th>
                                <td><?php echo htmlspecialchars($data->nama); ?></td>
                                <td><?php echo substr($data->tanggal_pesan, 0, 10); ?></td>
                                <td><?php echo htmlspecialchars($data->tanggal_digunakan); ?></td>
                                <td><?php echo htmlspecialchars($data->telephone); ?></td>
                                <td><?php echo htmlspecialchars($data->alamat); ?></td>
                                <td>
                                    <?php 
                                        if ($data->read == 0) {
                                            echo '<span style="color:red;">Belum dibaca</span>';
                                        } else {
                                            echo '<span style="color:green;">Sudah dibaca</span>';
                                        }
                                    ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table> 
            </div>
        </div>
    </div> 
</div> 

<?php include "layout/footer.php"; ?>
