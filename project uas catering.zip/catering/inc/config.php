<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


	// Koneksi ke database menggunakan mysqli
$koneksi = mysqli_connect("localhost", "root", "", "catering");


	// Cek koneksi
	if (!$koneksi) {
		die("Koneksi database gagal: " . mysqli_connect_error());
	}

	// Settings
	$url = "http://localhost/catering/";
	$title = "Website Pemesanan Katering";
	$no = 1;

	// Fungsi bantuan
	function alert($command){
		echo "<script>alert('".$command."');</script>";
	}
	function redir($command){
		echo "<script>document.location='".$command."';</script>";
	}
	function validate_admin_not_login($command){
		if(empty($_SESSION['iam_admin'])){
			redir($command);
		}
	}
?>
