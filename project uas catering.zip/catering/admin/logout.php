<?php include"../inc/config.php"; ?>

<?php
// Jika sudah klik "Ya", jalankan logout
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
	unset($_SESSION['iam_admin']);
	//session_destroy();
	redir($url . "index.php");
	exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
</head>
<body>
	<script>
		// Munculkan konfirmasi saat halaman dibuka
		if (confirm("apakah anda yakin ingin logout?")) {
			// Kalau user klik OK, tambahkan ?confirm=yes di URL untuk proses logout
			window.location.href = "logout.php?confirm=yes";
		} else {
			// Kalau user batal, kembali ke halaman sebelumnya
			window.history.back();
		}
	</script>
</body>
</html>
