<?php
	include "../inc/config.php";
	validate_admin_not_login("login.php");
	include "inc/header.php";

	// Query pakai mysqli, dan escape session id agar aman
	$admin_id = mysqli_real_escape_string($koneksi, $_SESSION['iam_admin']);
	$q = mysqli_query($koneksi, "SELECT * FROM user WHERE id='$admin_id'");
	$u = mysqli_fetch_object($q);
?>

<div class="container text-center" style="margin-top:20px; padding:50px;">
	<h2>Hi, <?php echo htmlspecialchars($u->nama); ?></h2>
	<h2> Selamat Datang di Panel Admin <h2>


</div> <!-- /container -->

<?php include "inc/footer.php"; ?>
