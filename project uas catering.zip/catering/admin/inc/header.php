<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/catering/inc/config.php");


// Validasi user sudah login sebagai admin
validate_admin_not_login("login.php");

// Hitung total pesan belum terbaca
$result = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM pesanan WHERE `read` = 0");
$row = mysqli_fetch_assoc($result);
$totalUnRead = $row['total'];

// Hitung total pembayaran pending
$result2 = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM pembayaran WHERE status = 'pending'");
$row2 = mysqli_fetch_assoc($result2);
$totalPending = $row2['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">    
<title><?php echo htmlspecialchars($title); ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="<?php echo htmlspecialchars($url); ?>assets/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo htmlspecialchars($url); ?>assets/bootstrap/css/datetimepicker.css" rel="stylesheet">
<link href="<?php echo htmlspecialchars($url); ?>assets/css/navbar-fixed-top.css" rel="stylesheet">
<link href="<?php echo htmlspecialchars($url); ?>assets/css/full-slider.css" rel="stylesheet">
<link href="<?php echo htmlspecialchars($url); ?>assets/css/style.css" rel="stylesheet">



<style>
  .navbar-blue {
    background-color:rgb(30, 55, 82) !important;
    border: none !important;
  }

  .navbar-blue .navbar-brand,
  .navbar-blue .navbar-nav > li > a {
    color: white !important;
  }

  .navbar-blue .navbar-nav > li > a:hover {
    background-color:rgb(30, 63, 83) !important;
    color: #ddd !important;
  }
</style>


</head>

<body>
<nav class="navbar navbar-default navbar-fixed-top navbar-blue">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
              aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Web Administrator</a>
    </div>
    <div id="navbar" class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo htmlspecialchars($url); ?>admin/index.php">Home</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
             aria-haspopup="true" aria-expanded="false">Master Data <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="user.php">Data User</a></li>
            <li><a href="produk.php">Data Produk</a></li>
            <li><a href="kategori_produk.php">Data Kategori Produk</a></li>
            <li><a href="kota.php">Kota & Ongkir</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
             aria-haspopup="true" aria-expanded="false">Laporan <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="laporan_pengeluaran.php">Laporan Pengeluaran</a></li>
            <li><a href="input_pengeluaran.php">Input Pengeluaran</a></li>
            <li><a href="laporan_laba_rugi.php">Laporan Laba Rugi</a></li>
            <li><a href="laporan.php">Laporan Penjualan</a></li>
           
          </ul>
        </li>
        <li><a href="pesanan.php">Pesanan
          <?php if ($totalUnRead > 0): ?>
              <span class="badge"><?php echo $totalUnRead; ?></span>
          <?php endif; ?>
          </a></li>
        <li><a href="pembayaran.php">Pembayaran
          <?php if ($totalPending > 0): ?>
              <span class="badge"><?php echo $totalPending; ?></span>
          <?php endif; ?>
          </a></li>
        <li><a href="kontak.php">Kontak</a></li>
        <li><a href="<?php echo htmlspecialchars($url); ?>admin/logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
