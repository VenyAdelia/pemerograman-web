<?php 
include "../inc/config.php"; 
validate_admin_not_login("login.php");

$no = 1;

if (!empty($_GET)) {
    $act = $_GET['act'] ?? '';

    if ($act === 'delete' && !empty($_GET['id'])) {
        $id = (int) $_GET['id'];
        $stmt = $koneksi->prepare("DELETE FROM kontak WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("kontak.php");
        }
        $stmt->close();
    }

    if ($act === 'create' && !empty($_POST)) {
        $nama = $_POST['nama'] ?? '';
        $email = $_POST['email'] ?? '';
        $subjek = $_POST['subjek'] ?? '';
        $pesan = $_POST['pesan'] ?? '';

        $stmt = $koneksi->prepare("INSERT INTO kontak (nama, email, subjek, pesan) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssss', $nama, $email, $subjek, $pesan);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("kontak.php");
        }
        $stmt->close();
    }

    if ($act === 'edit' && !empty($_POST) && !empty($_GET['id'])) {
        $id = (int) $_GET['id'];
        $nama = $_POST['nama'] ?? '';
        $email = $_POST['email'] ?? '';
        $subjek = $_POST['subjek'] ?? '';
        $pesan = $_POST['pesan'] ?? '';

        $stmt = $koneksi->prepare("UPDATE kontak SET nama=?, email=?, subjek=?, pesan=? WHERE id=?");
        $stmt->bind_param('ssssi', $nama, $email, $subjek, $pesan, $id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("kontak.php");
        }
        $stmt->close();
    }
}

include "inc/header.php";

$q = $koneksi->query("SELECT * FROM kontak");
$j = $q->num_rows;
?> 

<div class="container">
    <h4>Daftar Kontak Masuk (<?php echo $j > 0 ? $j : 0; ?>)</h4>
    <a class="btn btn-sm btn-primary" href="kontak.php?act=create">Add Data</a>
    <hr>

    <?php if (!empty($_GET['act'])):
        $act = $_GET['act'];
        if ($act === 'create'): ?>
            <div class="row col-md-6">
            <form action="" method="post" enctype="multipart/form-data">
                <label>Nama</label><br>
                <input type="text" class="form-control" name="nama" required><br>
                <label>Email</label><br>
                <input type="email" class="form-control" name="email" required><br>
                <label>Subjek</label><br>
                <input type="text" class="form-control" name="subjek" required><br>
                <label>Pesan</label><br>
                <textarea class="form-control" name="pesan" required></textarea><br>
                <input type="submit" name="form-input" value="Simpan" class="btn btn-success">
            </form>
            </div>
            <div class="row col-md-12"><hr></div>

        <?php elseif ($act === 'edit' && !empty($_GET['id'])):
            $id = (int) $_GET['id'];
            $stmt = $koneksi->prepare("SELECT * FROM kontak WHERE id = ?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $res = $stmt->get_result();
            $data = $res->fetch_object();
            $stmt->close();
            if ($data):
        ?>
            <div class="row col-md-6">
            <form action="kontak.php?act=edit&id=<?php echo $id ?>" method="post" enctype="multipart/form-data">
                <label>Nama</label><br>
                <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($data->nama); ?>" required><br>
                <label>Email</label><br>
                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($data->email); ?>" required><br>
                <label>Subjek</label><br>
                <input type="text" class="form-control" name="subjek" value="<?php echo htmlspecialchars($data->subjek); ?>" required><br>
                <label>Pesan</label><br>
                <textarea class="form-control" name="pesan" required><?php echo htmlspecialchars($data->pesan); ?></textarea><br>
                <input type="submit" name="form-edit" value="Simpan" class="btn btn-success">
            </form>
            </div>
            <div class="row col-md-12"><hr></div>
        <?php 
            else:
                echo '<div class="alert alert-warning">Data tidak ditemukan.</div>';
            endif;
        endif;
    endif; ?>

    <table class="table table-striped table-hover"> 
        <thead> 
            <tr> 
                <th>#</th> 
                <th>Nama</th> 
                <th>Email</th> 
                <th>Subjek</th> 
                <th>Pesan</th> 
                <th>Action</th> 
            </tr> 
        </thead> 
        <tbody> 
        <?php while ($data = $q->fetch_object()): ?> 
            <tr> 
 <th scope="row"><?php echo $no++; ?></th> 
 <td><?php echo htmlspecialchars($data->nama); ?></td> 
 <td><?php echo htmlspecialchars($data->email); ?></td> 
    <td><?php echo htmlspecialchars($data->subjek); ?></td>
		<td><?php echo htmlspecialchars($data->pesan); ?></td> 
          <td>
                    <a class="btn btn-sm btn-success" href="kontak.php?act=edit&id=<?php echo $data->id ?>">Edit</a>
                    <a class="btn btn-sm btn-danger" href="kontak.php?act=delete&id=<?php echo $data->id ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Delete</a>
                </td> 
            </tr>
        <?php endwhile; ?>
        </tbody> 
    </table> 
</div> <!-- /container -->

<?php include "inc/footer.php"; ?>
