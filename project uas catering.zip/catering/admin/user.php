<?php 
include_once "../inc/config.php"; 
validate_admin_not_login("login.php");

if (!empty($_GET)) {
    if ($_GET['act'] == 'delete') {
        $id = intval($_GET['id']);
        $stmt = $koneksi->prepare("DELETE FROM user WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("user.php");
        }
        $stmt->close();
    }
}

if (!empty($_GET['act']) && $_GET['act'] == 'create') {
    if (!empty($_POST)) {
        extract($_POST); 
        $password = md5($password);
        $stmt = $koneksi->prepare("INSERT INTO user (nama, email, telephone, alamat, password, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $nama, $email, $telephone, $alamat, $password, $status);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("user.php");
        }
        $stmt->close();
    }
}

if (!empty($_GET['act']) && $_GET['act'] == 'edit') {
    if (!empty($_POST)) {
        extract($_POST);
        $password = md5($password);
        $id = intval($_GET['id']);
        $stmt = $koneksi->prepare("UPDATE user SET nama=?, email=?, telephone=?, alamat=?, password=?, status=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nama, $email, $telephone, $alamat, $password, $status, $id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            alert("Success");
            redir("user.php");
        }
        $stmt->close();
    }
}

include "inc/header.php";
?> 

<div class="container">
    <?php
        $q = $koneksi->query("SELECT * FROM user");
        $j = $q->num_rows;
    ?>
    <h4>Daftar user Masuk (<?php echo ($j > 0) ? $j : 0; ?>)</h4>
    <a class="btn btn-sm btn-primary" href="user.php?act=create">Add Data</a>
    <hr>
    <?php
        if (!empty($_GET)) {
            if ($_GET['act'] == 'create') {
    ?>
    <div class="row col-md-6">
        <form action="" method="post" enctype="multipart/form-data">
            <label>Nama</label><br>
            <input type="text" class="form-control" name="nama" required><br>
            <label>Email</label><br>
            <input type="email" class="form-control" name="email" required><br>
            <label>Telephone</label><br>
            <input type="text" class="form-control" name="telephone" required><br>
            <label>Alamat</label><br>
            <input type="text" class="form-control" name="alamat" required><br>
            <label>Password</label><br>
            <input type="password" class="form-control" name="password" required><br>
            <label>Status</label><br> 
            <select name="status" required class="form-control"> 
                <option value="user">User</option> 
                <option value="admin">Admin</option> 
            </select><br>
            <input type="submit" name="form-input" value="Simpan" class="btn btn-success">
        </form>
    </div>
    <div class="row col-md-12"><hr></div>
    <?php   
            } 
            if ($_GET['act'] == 'edit') {
                $id = intval($_GET['id']);
                $stmt = $koneksi->prepare("SELECT * FROM user WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                $data = $result->fetch_object();
    ?>
    <div class="row col-md-6">
        <form action="user.php?act=edit&&id=<?php echo $_GET['id'] ?>" method="post" enctype="multipart/form-data">
            <label>Nama</label><br>
            <input type="text" class="form-control" name="nama" value="<?php echo $data->nama; ?>" required><br>
            <label>Email</label><br>
            <input type="email" class="form-control" name="email" value="<?php echo $data->email; ?>" required><br>
            <label>Telephone</label><br>
            <input type="text" class="form-control" name="telephone" value="<?php echo $data->telephone; ?>" required><br>
            <label>Alamat</label><br>
            <input type="text" class="form-control" name="alamat" value="<?php echo $data->alamat; ?>" required><br>
            <label>Password</label><br>
            <input type="password" class="form-control" name="password" required><br>
            <label>Status</label><br>
            <select name="status" required class="form-control"> 
                <option value="<?php echo $data->status; ?>"><?php echo $data->status; ?></option>
                <option value="user">User</option> 
                <option value="admin">Admin</option> 
            </select><br>
            <input type="submit" name="form-edit" value="Simpan" class="btn btn-success">
        </form>
    </div>
    <div class="row col-md-12"><hr></div>
    <?php
                $stmt->close();
            } 
        }
    ?>

    <table class="table table-striped table-hover"> 
        <thead> 
            <tr> 
                <th>no</th> 
                <th>Nama</th> 
                <th>Email</th> 
                <th>Telephone</th> 
                <th>Alamat</th> 
                <th>Status</th> 
                <th>Aksi</th> 
            </tr> 
        </thead> 
        <tbody> 
        <?php 
            $no = 1;
            while ($data = $q->fetch_object()) { 
        ?> 
            <tr> 
                <th scope="row"><?php echo $no++; ?></th> 
                <td><?php echo $data->nama ?></td> 
                <td><?php echo $data->email ?></td> 
                <td><?php echo $data->telephone ?></td> 
                <td><?php echo $data->alamat ?></td> 
                <td><?php echo $data->status ?></td> 
                <td>
                    <a class="btn btn-sm btn-success" href="user.php?act=edit&&id=<?php echo $data->id ?>">Edit</a>
                    <a class="btn btn-sm btn-danger" href="user.php?act=delete&&id=<?php echo $data->id ?>">Delete</a>
                </td> 
            </tr>
        <?php } ?>
        </tbody> 
    </table> 
</div> <!-- /container -->

<?php include "inc/footer.php"; ?>
