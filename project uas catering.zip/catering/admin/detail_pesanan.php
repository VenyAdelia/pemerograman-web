<?php
include "../inc/config.php";
validate_admin_not_login("login.php");
include "inc/header.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    mysqli_query($koneksi, "UPDATE pesanan SET `read` = 1 WHERE id = $id");
}


if (!isset($_GET['id'])) {
    echo "<p>ID pesanan tidak ditemukan.</p>";
    exit;
}

$id = intval($_GET['id']);
$query = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id = $id");
$data = mysqli_fetch_object($query);

if (!$data) {
    echo "<p>Data pesanan tidak ditemukan.</p>";
    exit;
}

// Ambil detail pesanan
$list = mysqli_query($koneksi, "SELECT dp.*, p.nama AS nama_produk, p.harga 
    FROM detail_pesanan dp 
    JOIN produk p ON dp.produk_id = p.id 
    WHERE dp.pesanan_id = $id");


if (!$list) {
    echo "Query detail_pesanan gagal: " . mysqli_error($koneksi);
    exit;
}

// Hitung total belanja
$total = 0;
$rows = [];
while ($row = mysqli_fetch_assoc($list)) {
    $subtotal = $row['qty'] * $row['harga'];
    $row['subtotal'] = $subtotal;
    $total += $subtotal;
    $rows[] = $row;
}

$totalBayar = $total + $data->ongkir;
// Ambil total dibayar dari tabel pembayaran yang sudah diverifikasi
$dibayarQuery = mysqli_query($koneksi, "SELECT SUM(total) AS total_dibayar FROM pembayaran WHERE id_pesanan = $id AND status = 'verified'");
$dibayarData = mysqli_fetch_assoc($dibayarQuery);
$dibayar = $dibayarData['total_dibayar'] ?? 0;

// Hitung kekurangan
$kekurangan = max($totalBayar - $dibayar, 0);
$kekurangan = $totalBayar - $dibayar;
?>

<div class="container">
    <h3>Pesanan Detail</h3>
    <table class="table table-bordered">
        <tr><td>Nama Pemesan</td><td><?= htmlspecialchars($data->nama) ?></td></tr>
        <tr><td>Tanggal Pesan</td><td><?= $data->tanggal_pesan ?></td></tr>
        <tr><td>Tanggal Digunakan</td><td><?= $data->tanggal_digunakan ?></td></tr>
        <tr><td>Telephone</td><td><?= $data->telephone ?></td></tr>
        <tr><td>Alamat</td><td><?= htmlspecialchars($data->alamat) ?></td></tr>
        <tr><td>Total Bayar</td><td>Rp. <?= number_format($totalBayar, 2, ',', '.') ?></td></tr>
        <tr><td>Dibayar</td><td>Rp. <?= number_format($dibayar, 2, ',', '.') ?></td></tr>
        <tr><td>Kekurangan</td><td>Rp. <?= number_format($kekurangan, 2, ',', '.') ?></td></tr>
        <tr><td>Status</td><td><?= $data->status ?></td></tr>
    </table>

    <h4>List Pesanan</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama Produk</th>
                <th>Harga Satuan</th>
                <th>QTY</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $index => $row): ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= htmlspecialchars($row['nama_produk']) ?></td>
                    <td>Rp. <?= number_format($row['harga'], 2, ',', '.') ?></td>
                    <td><?= $row['qty'] ?></td>
                    <td>Rp. <?= number_format($row['subtotal'], 2, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>

<tr>
    <td colspan="4" style="text-align:right;"><strong>KOTA & ONGKIR</strong></td>
    <td><strong><?= htmlspecialchars($data->kota) ?> - Rp. <?= number_format($data->ongkir, 2, ',', '.') ?></strong></td>
</tr>
<tr>
    <td colspan="4" style="text-align:right;"><strong>TOTAL HARGA</strong></td>
    <td><strong>Rp. <?= number_format($totalBayar, 2, ',', '.') ?></strong></td>
</tr>


        </tbody>
    </table>

    <a href="pesanan.php" class="btn btn-secondary">« Kembali</a>
</div>

<?php include "inc/footer.php"; ?>
