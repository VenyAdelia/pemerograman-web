<?php
include("../inc/config.php");
include "inc/header.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil total pendapatan (qty * harga dari detail_pesanan dan produk)
$q = mysqli_query($koneksi, "
    SELECT SUM(dp.qty * p.harga) AS total_pendapatan
    FROM detail_pesanan dp
    JOIN produk p ON dp.produk_id = p.id
");
$d = mysqli_fetch_array($q);
$total_pendapatan = $d['total_pendapatan'] ?? 0;

// Ambil total pengeluaran dari tabel laporan (gunakan kolom 'total')
$pengeluaran = mysqli_query($koneksi, "
    SELECT SUM(total) AS total_pengeluaran FROM laporan
");
$dp = mysqli_fetch_array($pengeluaran);
$total_pengeluaran = $dp['total_pengeluaran'] ?? 0;

// Hitung laba/rugi
$laba_rugi = $total_pendapatan - $total_pengeluaran;
?>

<div class="container">
    <h2>Laporan Laba Rugi</h2>
    <table class="table table-bordered">
        <tr><th>Total Pendapatan</th><td>Rp. <?= number_format($total_pendapatan, 0, ',', '.') ?></td></tr>
        <tr><th>Total Pengeluaran</th><td>Rp. <?= number_format($total_pengeluaran, 0, ',', '.') ?></td></tr>
        <tr><th><b>Laba/Rugi</b></th><td><b>Rp. <?= number_format($laba_rugi, 0, ',', '.') ?></b></td></tr>
    </table>
</div>

<?php include "inc/footer.php"; ?>
