<?php
include "../inc/config.php";
validate_admin_not_login("login.php");

// Inisialisasi nomor untuk tabel
$no = 1;

// Handle delete
if (!empty($_GET) && $_GET['act'] == 'delete' && !empty($_GET['id'])) {
    $id = (int)$_GET['id'];
    $q = mysqli_query($koneksi, "DELETE FROM laporan WHERE id_pengeluaran='$id'");
    if ($q) {
        alert("Success");
        redir("input_pengeluaran.php");
    }
}

// Handle create
if (!empty($_GET['act']) && $_GET['act'] == 'create' && !empty($_POST)) {
    $nama_barang = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $Tanggal_pengeluaran = mysqli_real_escape_string($koneksi, $_POST['Tanggal_pengeluaran']);
    $harga = (float)$_POST['harga'];
    $jumlah = (int)$_POST['jumlah'];
    $total = $harga * $jumlah;

    $q = mysqli_query($koneksi, "INSERT INTO laporan VALUES(NULL, '$nama_barang', '$Tanggal_pengeluaran', '$harga', '$jumlah', '$total')");
    if ($q) {
        alert("Success");
        redir("input_pengeluaran.php");
    }
}

// Handle edit
if (!empty($_GET['act']) && $_GET['act'] == 'edit' && !empty($_POST) && !empty($_GET['id'])) {
    $id = (int)$_GET['id'];
    $nama_barang = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $harga = (float)$_POST['harga'];
    $jumlah = (int)$_POST['jumlah'];
    $total = $harga * $jumlah;

    $q = mysqli_query($koneksi, "UPDATE laporan SET nama_barang='$nama_barang', harga='$harga', jumlah='$jumlah', total='$total' WHERE id_pengeluaran='$id'");
    if ($q) {
        alert("Success");
        redir("input_pengeluaran.php");
    }
}

include "inc/header.php";
?>

<div class="container">
    <?php
    $q = mysqli_query($koneksi, "SELECT * FROM laporan");
    $j = mysqli_num_rows($q);
    ?>
    <h4>Input Pengeluaran (<?php echo $j > 0 ? $j : 0; ?>)</h4>
    <a class="btn btn-sm btn-primary" href="input_pengeluaran.php?act=create">Add Data</a>
    <hr>
    <?php
    if (!empty($_GET)) {
        if ($_GET['act'] == 'create') {
            ?>
            <div class="row col-md-6">
                <form action="" method="post" enctype="multipart/form-data">
                    <label>Nama Barang</label><br>
                    <input type="text" class="form-control" name="nama_barang" required placeholder="Masukkan Nama Barang"><br>
                    <label>Tanggal Pengeluaran</label><br>
                    <div class="form-group">
                        <div class='input-group date' id='datetimepicker'>
                            <input type='text' class="form-control" name="Tanggal_pengeluaran" required placeholder="Pilih Tanggal" />
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                        </div>
                    </div>
                    <label>Harga</label><br>
                    <input type="number" step="0.01" class="form-control" name="harga" required placeholder="Masukkan Harga"><br>
                    <label>Jumlah</label><br>
                    <input type="number" class="form-control" name="jumlah" required placeholder="Masukkan Jumlah"><br>
                    <input type="submit" name="form-input" value="Simpan" class="btn btn-success">
                </form>
            </div>
            <div class="row col-md-12"><hr></div>
            <?php
        }
        if ($_GET['act'] == 'edit' && !empty($_GET['id'])) {
            $id = (int)$_GET['id'];
            $data = mysqli_fetch_object(mysqli_query($koneksi, "SELECT * FROM laporan WHERE id_pengeluaran='$id'"));
            ?>
            <div class="row col-md-6">
                <form action="input_pengeluaran.php?act=edit&id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
                    <label>Nama Barang</label><br>
                    <input type="text" class="form-control" name="nama_barang" value="<?php echo htmlspecialchars($data->nama_barang); ?>" required><br>
                    <label>Harga</label><br>
                    <input type="number" step="0.01" class="form-control" name="harga" value="<?php echo $data->harga; ?>" required><br>
                    <label>Jumlah</label><br>
                    <input type="number" class="form-control" name="jumlah" value="<?php echo $data->jumlah; ?>" required><br>
                    <input type="submit" name="form-edit" value="Simpan" class="btn btn-success">
                </form>
            </div>
            <div class="row col-md-12"><hr></div>
            <?php
        }
    }
    ?>

    <table class="table table-striped table-hover">
        <thead>
        <tr>
            <th>NO</th>
            <th>Nama Barang</th>
            <th>Tanggal Pengeluaran</th>
            <th>Harga</th>
            <th>Jumlah Barang</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Reset $no
        $no = 1;
        mysqli_data_seek($q, 0); // reset result pointer
        while ($data = mysqli_fetch_object($q)) {
            $tgl = explode("-", $data->Tanggal_pengeluaran);
            $tgl1 = $tgl[2] . '-' . $tgl[1] . '-' . $tgl[0];
            ?>
            <tr>
                <th scope="row"><?php echo $no++; ?></th>
                <td><?php echo htmlspecialchars($data->nama_barang); ?></td>
                <td><?php echo $tgl1; ?></td>
                <td><?php echo "Rp. " . number_format($data->harga, 2, ",", "."); ?></td>
                <td><?php echo (int)$data->jumlah; ?></td>
                <td><?php echo "Rp. " . number_format($data->total, 2, ",", "."); ?></td>
                <td>
                    <a class="btn btn-sm btn-success" href="input_pengeluaran.php?act=edit&id=<?php echo $data->id_pengeluaran; ?>">Edit</a>
                    <a class="btn btn-sm btn-danger" href="input_pengeluaran.php?act=delete&id=<?php echo $data->id_pengeluaran; ?>" onclick="return confirm('Yakin ingin menghapus data ini?');">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</div> <!-- /container -->

<?php include "inc/footer.php"; ?>
