<?php
ob_start();
include "../inc/config.php";
validate_admin_not_login("login.php");

if ($_GET['act'] ?? null !== "cetak") {
    include "inc/header.php";
}
?>
<div class="container">
    <h4>Laporan Penjualan</h4>
   
    <div class="col-md-12"><hr/></div>
    <div class="row">
        <table class="table table-striped" border="1">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Tanggal Tempo</th>
                    <th>Tanggal Pesan</th>
                    <th>Total</th>
                    <th>Ongkir</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalSemua = 0;
                $totalOngkir = 0;
                $no = 0;

                // Ambil data pesanan beserta total harga per pesanan sekaligus
                $query = "
                    SELECT pesanan.*, 
                        COALESCE(SUM(produk.harga * detail_pesanan.qty), 0) AS totalHarga
                    FROM pesanan
                    LEFT JOIN detail_pesanan ON detail_pesanan.pesanan_id = pesanan.id
                    LEFT JOIN produk ON detail_pesanan.produk_id = produk.id
                    GROUP BY pesanan.id
                    ORDER BY pesanan.id DESC
                ";
                $result = mysqli_query($koneksi, $query) or die(mysqli_error($koneksi));

                while ($data = mysqli_fetch_object($result)) {
                    $no++;
                    $totalSemua += $data->totalHarga;
                    $totalOngkir += $data->ongkir;

                    // Escape output untuk keamanan
                    $nama = htmlspecialchars($data->nama);
                    $tanggalTempo = htmlspecialchars($data->tanggal_digunakan);
                    $tanggalPesan = htmlspecialchars($data->tanggal_pesan);
                    $status = htmlspecialchars($data->status);
                    ?>
                    <tr>
                        <td><?php echo $no; ?></td>
                        <td><?php echo $nama; ?></td>
                        <td><?php echo $tanggalTempo; ?></td>
                        <td><?php echo $tanggalPesan; ?></td>
                        <td><?php echo "Rp. " . number_format($data->totalHarga, 2, ",", "."); ?></td>
                        <td><?php echo "Rp. " . number_format($data->ongkir, 2, ",", "."); ?></td>
                        <td><?php echo $status; ?></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="4" align="right"><b>TOTAL</b></td>
                    <td><b><?php echo "Rp. " . number_format($totalSemua, 2, ",", "."); ?></b></td>
                    <td><b><?php echo "Rp. " . number_format($totalOngkir, 2, ",", "."); ?></b></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
if (($_GET['act'] ?? null) === "cetak") {
    $html = ob_get_contents();
    ob_end_clean();
    include("../assets/MPDF57/mpdf.php");
    $mpdf = new mPDF();

    $stylesheet = file_get_contents('../assets/css/style.css');
    $mpdf->WriteHTML($stylesheet, 1);
    $mpdf->WriteHTML(utf8_encode($html), 2);
    $mpdf->Output();
    exit;
} else {
    include "inc/footer.php";
}
?>
