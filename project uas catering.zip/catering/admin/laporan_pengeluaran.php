<?php

	ob_start();
	include "../inc/config.php";
	validate_admin_not_login("login.php");
	if (@$_GET['act'] != "cetak") {
		include "inc/header.php";
	}
?>
<div class="container">
	<h4>Laporan Pengeluaran</h4>
	
	<div class="col-md-12">
		<hr/>
	</div>

	<div class="row">
		<table class="table table-striped" border="1">
			<tr>
				<th>No</th>
				<th>Nama barang</th>
				<th>Tanggal Pengeluaran</th>
				<th>Harga</th>
				<th>Jumlah Barang</th>
				<th>Total</th>
			</tr>
			<tbody>
				<?php
					$totalall = 0;
					$no = 0;

					$q = mysqli_query($koneksi, "SELECT * FROM laporan ORDER BY id_pengeluaran DESC") or die(mysqli_error($koneksi));
					while ($data = mysqli_fetch_object($q)) {
						$no++;
						$totalall += $data->total;
						// Format tanggal dd-mm-yyyy
						$tgl = explode("-", $data->Tanggal_pengeluaran);
						$tgl1 = $tgl[2] . '-' . $tgl[1] . '-' . $tgl[0];
						?>
						<tr>
							<td><?php echo $no; ?></td>
							<td><?php echo htmlspecialchars($data->nama_barang); ?></td>
							<td><?php echo $tgl1; ?></td>
							<td><?php echo "Rp. " . number_format($data->harga, 2, ",", "."); ?></td>
							<td><?php echo (int)$data->jumlah; ?></td>
							<td><?php echo "Rp. " . number_format($data->total, 2, ",", "."); ?></td>
						</tr>
						<?php
					}
				?>
				<tr>
					<td colspan="5" align="right">
						<font size="3"><b>TOTAL</b></font>
					</td>
					<td>
						<font size="3"><?php echo "Rp. " . number_format($totalall, 2, ",", "."); ?></font>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<?php
if (@$_GET['act'] == "cetak") {
	$html = ob_get_contents(); // ambil output buffer
	ob_end_clean();
	include("../assets/MPDF57/mpdf.php");
	$mpdf = new mPDF();
	$stylesheet = file_get_contents('../assets/css/style.css');
	$mpdf->WriteHTML($stylesheet, 1);
	$mpdf->WriteHTML(utf8_encode($html), 2);
	$mpdf->Output();
	exit;
} else {
	include "inc/footer.php";
}
?>
