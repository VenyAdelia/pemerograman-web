<?php 
session_start();
include "inc/config.php";
include "layout/header.php";

if (empty($_SESSION['iam_user'])) {
    echo "<script>alert('Silahkan login dahulu.');</script>";
    echo "<script>window.location='login.php';</script>";
    exit;
}

// Ambil data user menggunakan mysqli
$user_id = $_SESSION['iam_user'];
$user_query = mysqli_prepare($koneksi, "SELECT * FROM user WHERE id = ?");
mysqli_stmt_bind_param($user_query, "i", $user_id);
mysqli_stmt_execute($user_query);
$user_result = mysqli_stmt_get_result($user_query);
$user = mysqli_fetch_object($user_result);

$no = 1;

// Ambil data pesanan terakhir user
$pesanan_query = mysqli_prepare($koneksi, "SELECT * FROM pesanan WHERE user_id = ? ORDER BY id DESC LIMIT 1");
mysqli_stmt_bind_param($pesanan_query, "i", $user_id);
mysqli_stmt_execute($pesanan_query);
$pesanan_result = mysqli_stmt_get_result($pesanan_query);
$pes = mysqli_fetch_assoc($pesanan_result);

$ongkir = $pes['ongkir'];
$total = 0;
?>

<div class="col-md-9">

    <div class="alert alert-success">pemesanan anda Berhasil. Silahkan melakukan pembayaran sesuai total belanja</div>
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h4>Detail Pesanan yang anda beli:</h4>
            <table class="table table-striped table-hover"> 
                <thead> 
                    <tr> 
                        <th>#</th> 
                        <th>Nama Produk</th> 
                        <th>Harga Satuan</th> 
                        <th>QTY</th> 
                        <th>Harga *</th>   
                    </tr> 
                </thead> 
                <tbody> 
                <?php
                // Ambil detail pesanan
                $detail_query = mysqli_prepare($koneksi, "SELECT * FROM detail_pesanan WHERE pesanan_id = ?");
                mysqli_stmt_bind_param($detail_query, "i", $pes['id']);
                mysqli_stmt_execute($detail_query);
                $detail_result = mysqli_stmt_get_result($detail_query);

                while ($data = mysqli_fetch_object($detail_result)) {
                    // Ambil data produk
                    $produk_query = mysqli_prepare($koneksi, "SELECT * FROM produk WHERE id = ?");
                    mysqli_stmt_bind_param($produk_query, "i", $data->produk_id);
                    mysqli_stmt_execute($produk_query);
                    $produk_result = mysqli_stmt_get_result($produk_query);
                    $p = mysqli_fetch_object($produk_result);

                    $t = $data->qty * $p->harga;
                    $total += $t;
                ?>
                    <tr> 
                        <th scope="row"><?php echo $no++; ?></th> 
                        <td><?php echo htmlspecialchars($p->nama); ?></td> 
                        <td><?php echo number_format($p->harga, 2, ',', '.'); ?></td>  
                        <td><?php echo $data->qty; ?></td>
                        <td><?php echo number_format($t, 2, ',', '.'); ?></td>  
                    </tr>
                <?php } ?>
                    <tr>
                        <td colspan="4" class="text-center">
                            <h5><b>ONGKIR</b></h5>
                        </td>
                        <td class="text-bold">
                            <h5><b><?php echo number_format($ongkir, 2, ',', '.'); ?></b></h5>
                        </td>                
                    </tr>
                    <tr>
                        <td colspan="4" class="text-center">
                            <h5><b>TOTAL HARGA</b></h5>
                        </td>
                        <td class="text-bold">
                            <h5><b><?php echo number_format($total + $ongkir, 2, ',', '.'); ?></b></h5>
                        </td>
                    </tr>
                </tbody> 
            </table>
        </div> 
    </div> 
</div> 

<?php include "layout/footer.php"; ?>
