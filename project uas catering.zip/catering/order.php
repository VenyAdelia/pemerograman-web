<?php
ob_start();
session_start();
include "inc/config.php";
include "layout/header.php";

// Cek login
if(empty($_SESSION['iam_user'])){
    alert("Silahkan login dahulu.");
    redir("login.php");
    exit;
}

$user_id = $_SESSION['iam_user'];

// Ambil data user
$user_stmt = $koneksi->prepare("SELECT * FROM user WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_object();

// Ambil isi keranjang
$cart = !empty($_SESSION['cart']) ? unserialize($_SESSION['cart']) : [];
if(!is_array($cart)) $cart = [];

$total_qty = array_sum($cart);
if ($total_qty < 40) {
    alert("Minimal pemesanan 40 porsi. Silakan tambahkan menu terlebih dahulu.");
    redir("keranjang.php");
    exit;
}

if (!empty($_POST['form-order'])) {
    $nama = $_POST['nama'];
    $telephone = $_POST['telephone'];
    $alamat = $_POST['alamat'];
    $tanggal_digunakan = $_POST['tanggal_digunakan'];
    $kota_id = $_POST['kota'];

    $tanggal_pesan = date('Y-m-d H:i:s');
    $val_pesan = new DateTime(date('Y-m-d'));
    $val_digunakan = new DateTime(substr($tanggal_digunakan, 0, 10));
    $difference = $val_digunakan->diff($val_pesan);

    $kota_stmt = $koneksi->prepare("SELECT * FROM kota WHERE id = ?");
    $kota_stmt->bind_param("i", $kota_id);
    $kota_stmt->execute();
    $kt = $kota_stmt->get_result()->fetch_object();

    if ($difference->days >= 3) {
        // Simpan ke tabel pesanan
        $pesanan_stmt = $koneksi->prepare("INSERT INTO pesanan (tanggal_pesan, tanggal_digunakan, user_id, nama, alamat, kota, ongkir, telephone, `read`, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'belum lunas')");
        $pesanan_stmt->bind_param("ssisssis", $tanggal_pesan, $tanggal_digunakan, $user_id, $nama, $alamat, $kt->nama, $kt->ongkir, $telephone);
        $pesanan_stmt->execute();
        $last_id = $koneksi->insert_id;

        // Simpan detail pesanan
        foreach($cart as $id => $qty){
            $product_stmt = $koneksi->prepare("SELECT * FROM produk WHERE id = ?");
            $product_stmt->bind_param("i", $id);
            $product_stmt->execute();
            $product = $product_stmt->get_result()->fetch_assoc();

            if (!empty($product)) {
                $detail_stmt = $koneksi->prepare("INSERT INTO detail_pesanan (produk_id, qty, pesanan_id) VALUES (?, ?, ?)");
                $detail_stmt->bind_param("iii", $id, $qty, $last_id);
                $detail_stmt->execute();
            }
        }

        // Hapus keranjang & redirect ke success
        unset($_SESSION['cart']);
        header("Location: success.php");
        exit;

    } else {
        echo '<div class="alert alert-danger">Tanggal penggunaan terlalu dekat. Minimal pemesanan harus 3 hari sebelum hari H.</div>';
    }
}
?>

<!-- Form & Tampilan -->
<div class="col-md-9">
    <div class="row">
        <div class="col-md-7">
            <h4>Pengisian Data Pembeli :</h4>
            <hr>
            <form action="" method="post" enctype="multipart/form-data">
                <label>Waktu Pengiriman</label><br>
                <div class="form-group">
                    <input type="date" class="form-control" name="tanggal_digunakan" value="<?= htmlspecialchars($_POST['tanggal_digunakan'] ?? '') ?>" required>
                </div>
                <label>Nama</label><br>
                <input type="text" class="form-control" name="nama" required value="<?= htmlspecialchars($_POST['nama'] ?? $user->nama) ?>"><br>
                <label>Telephone (HP)</label><br>
                <input type="text" class="form-control" name="telephone" required value="<?= htmlspecialchars($_POST['telephone'] ?? $user->telephone) ?>"><br>
                <label>Alamat Pengiriman</label><br>
                <input type="text" class="form-control" name="alamat" required value="<?= htmlspecialchars($_POST['alamat'] ?? $user->alamat) ?>"><br>
                <label>Kota</label><br>
                <select name="kota" required class="form-control">
                    <?php
                    $kota_result = $koneksi->query("SELECT * FROM kota");
                    while($kp = $kota_result->fetch_assoc()){
                        $selected = (isset($_POST['kota']) && $_POST['kota'] == $kp['id']) ? 'selected' : '';
                        echo "<option value='{$kp['id']}' $selected>{$kp['nama']} - Rp " . number_format($kp['ongkir'], 2, ',', '.') . "</option>";
                    }
                    ?>
                </select><br>
                <input type="submit" name="form-order" value="Proses" class="btn btn-success">
            </form>
        </div>

        <div class="col-md-12">
            <hr>
            <h4>Detail Pesanan :</h4>
            <table class="table table-striped" style="width:100%">
                <thead>
                    <tr style="background:#c3ebf8;font-weight:bold;">
                        <td style="width:15%">Produk</td>
                        <td style="width:40%">Details</td>
                        <td style="width:10%">QTY</td>
                        <td style="width:15%">Total</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach($cart as $id => $qty){
                        $product_stmt = $koneksi->prepare("SELECT * FROM produk WHERE id = ?");
                        $product_stmt->bind_param("i", $id);
                        $product_stmt->execute();
                        $product = $product_stmt->get_result()->fetch_assoc();

                        if(!empty($product)){
                            $t = $qty * $product['harga'];
                            $total += $t;
                            ?>
                            <tr class="barang-shop">
                                <td><a href="menu.php?id=<?= $product['id'] ?>"><img src="uploads/<?= htmlspecialchars($product['gambar']) ?>" alt="img" width="120px"></a></td>
                                <td>
                                    <h4><a href="menu.php?id=<?= $product['id'] ?>"><?= htmlspecialchars($product['nama']) ?></a></h4>
                                    <div class="price">Rp <?= number_format($product['harga'], 2, ',', '.') ?></div>
                                </td>
                                <td><?= $qty ?> pcs</td>
                                <td class="price"><?= number_format($t, 2, ',', '.') ?></td>
                            </tr>
                        <?php }
                    } ?>
                    <tr style="background:#c3ebf8;font-weight:bold;">
                        <td colspan="3">TOTAL</td>
                        <td>Rp <?= number_format($total, 2, ',', '.') ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include "layout/footer.php"; ?>
