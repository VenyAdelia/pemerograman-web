<?php 
session_start();
include "inc/config.php";  // Pastikan fungsi alert() & redir() ada di sini

if (!empty($_SESSION['iam_user']) || !empty($_SESSION['iam_admin'])) {
    if (!empty($_SESSION['iam_admin'])) {
        redir("admin/index.php");
    } else {
        redir("index.php");
    }
}

include "layout/header.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $koneksi->prepare("SELECT id, password, status FROM user WHERE email = ? LIMIT 1");
    if (!$stmt) {
        die("Query error: " . $koneksi->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (md5($password) === $user['password']) {
            if ($user['status'] === 'admin') {
                $_SESSION['iam_admin'] = $user['id'];
                redir("admin/index.php");
            } else {
                $_SESSION['iam_user'] = $user['id'];
                redir("index.php");
            }
        } else {
            alert("Email atau password salah.");
        }
    } else {
        alert("Email atau password salah.");
    }
    $stmt->close();
}
?>

<style>
    .login-container {
        max-width: 450px;
        margin: 60px auto;
        background: #fff;
        padding: 40px 30px;
        border-radius: 12px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
    }

    .login-container h3 {
        text-align: center;
        margin-bottom: 30px;
        color: #333;
    }

    .form-label {
        font-weight: 500;
        margin-bottom: 6px;
    }

    .form-control {
        margin-bottom: 18px;
        border-radius: 8px;
        border: 1px solid #ccc;
        padding: 10px 14px;
        transition: border 0.3s;
    }

    .form-control:focus {
        border-color: #28a745;
        outline: none;
    }

    .btn-login {
        width: 100%;
        padding: 12px;
        font-weight: 600;
        border-radius: 8px;
    }

    .register-text {
        text-align: center;
        margin-top: 20px;
        font-size: 14px;
    }

    .register-text a {
        color: #007bff;
        text-decoration: none;
    }

    .register-text a:hover {
        text-decoration: underline;
    }
</style>

<div class="login-container">
    <h3>Login</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" placeholder="Email" required autofocus>

        <label class="form-label">Password</label>
        <input type="password" class="form-control" name="password" placeholder="Password" required>

        <input type="submit" name="form-input" value="Login" class="btn btn-success btn-login">
    </form>
    <div class="register-text">
        Belum Punya Akun? <a href="register.php">Buat Akun Sekarang!</a>
    </div>
</div>

<?php include "layout/footer.php"; ?>
