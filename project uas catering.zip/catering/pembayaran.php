<?php
include "inc/config.php";

// Hapus pesanan jika diminta
if(!empty($_GET['act']) && $_GET['act'] === 'delete' && !empty($_GET['id'])){
    $id = (int)$_GET['id'];
    $stmt = $koneksi->prepare("DELETE FROM pesanan WHERE id = ?");
    $stmt->bind_param("i", $id);
    if($stmt->execute()){
        alert("Success");
        redir("pembayaran.php");
    }
    $stmt->close();
}

// Cek login
if(empty($_SESSION['iam_user'])){
    redir("index.php");
}

$user_id = (int)$_SESSION['iam_user'];

// Ambil data user
$stmt = $koneksi->prepare("SELECT * FROM user WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_object();
$stmt->close();

include "layout/header.php";

// Ambil semua pesanan user yang belum lunas
$stmt = $koneksi->prepare("SELECT * FROM pesanan WHERE user_id = ? AND status = 'belum lunas'");
if (!$stmt) {
    die("Prepare failed: " . $koneksi->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$q = $stmt->get_result();

$no = 1;
?>

<div class="col-md-9 content-menu">
<div class="col-md-12">

<?php
if(!empty($_GET['act']) && $_GET['id']){
    $id = (int)$_GET['id'];

    $stmt = $koneksi->prepare("SELECT * FROM detail_pesanan WHERE pesanan_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $q1 = $stmt->get_result();

    $total = 0;

    $stmt2 = $koneksi->prepare("SELECT * FROM pesanan WHERE id = ?");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $dataPesanan = $stmt2->get_result()->fetch_object();
    $kota = $dataPesanan->kota;
    $ongkir = $dataPesanan->ongkir;
    $stmt2->close();

    while($data = $q1->fetch_object()){
        $stmt3 = $koneksi->prepare("SELECT * FROM produk WHERE id = ?");
        $stmt3->bind_param("i", $data->produk_id);
        $stmt3->execute();
        $p = $stmt3->get_result()->fetch_object();
        $stmt3->close();

        $t = $data->qty * $p->harga;
        $total += $t;
    }

    if($_GET['act'] === 'bayar'){
        if($_SERVER['REQUEST_METHOD'] === 'POST'){
            $bayar = $_POST['bayar'];
            $keterangan = $_POST['keterangan'];

            if(isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK){
                $fileTmpPath = $_FILES['gambar']['tmp_name'];
                $fileName = $_FILES['gambar']['name'];
                $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
                $newFileName = md5(date('Y-m-d H:i:s')).'.'.$fileExtension;
                $uploadFileDir = 'uploads/';
                $dest_path = $uploadFileDir . $newFileName;

                if(move_uploaded_file($fileTmpPath, $dest_path)){
                    $stmtInsert = $koneksi->prepare("INSERT INTO pembayaran (id_pesanan, id_user, file, total, status, keterangan, created_at) VALUES (?, ?, ?, ?, 'pending', ?, NOW())");
                    if (!$stmtInsert) {
                        die("Prepare INSERT failed: " . $koneksi->error);
                    }
                    $stmtInsert->bind_param("iisis", $id, $user_id, $newFileName, $bayar, $keterangan);

                    if($stmtInsert->execute()){
                        alert("Success");
                        redir("pembayaran.php");
                    } else {
                        echo '<div class="alert alert-danger">Gagal menyimpan data pembayaran.</div>';
                    }
                    $stmtInsert->close();
                } else {
                    echo '<div class="alert alert-danger">Gagal meng-upload file bukti pembayaran.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">File bukti pembayaran harus di-upload.</div>';
            }
        }

        $pesanan = $dataPesanan;

        $stmtCheck = $koneksi->prepare("SELECT * FROM pembayaran WHERE id_pesanan = ? AND status = 'verified'");
        $stmtCheck->bind_param("i", $id);
        $stmtCheck->execute();
        $qPembayaran = $stmtCheck->get_result();

        $totalPembayaran = 0;
        while ($d = $qPembayaran->fetch_object()) {
            $totalPembayaran += $d->total;
        }
        $stmtCheck->close();
        ?>

        <div class="row col-md-6">
        <form action="" method="post" enctype="multipart/form-data">
            <label>Total</label><br>
            <input type="text" class="form-control" value="<?php echo 'Rp. ' . number_format($total + $pesanan->ongkir, 2, ',', '.'); ?>" disabled><br>
            <label>Dibayar</label><br>
            <input type="text" class="form-control" value="<?php echo 'Rp. ' . number_format($totalPembayaran, 2, ',', '.'); ?>" disabled><br>
            <label>Kekurangan</label><br>
            <input type="text" class="form-control" value="<?php echo 'Rp. ' . number_format($total + $pesanan->ongkir - $totalPembayaran, 2, ',', '.'); ?>" disabled><br>
            <label>Bayar</label><br>
            <input type="number" class="form-control" name="bayar" step="0.01" required><br>
            <label>Bukti Pembayaran</label><br>
            <input type="file" class="form-control" name="gambar" required><br>
            <label>Keterangan</label><br>
            <textarea class="form-control" name="keterangan"></textarea><br/>
            <input type="submit" name="form-input" value="Kirim" class="btn btn-success">
            
        </form>
<script>
    const bayarInput = document.querySelector('input[name="bayar"]');
    const dibayarField = document.querySelectorAll('input.form-control[disabled]')[1]; // kolom ke-2 yg disabled (Dibayar)

    bayarInput.addEventListener('input', () => {
        const value = parseFloat(bayarInput.value);
        if (!isNaN(value)) {
            dibayarField.value = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR'
            }).format(value);
        } else {
            dibayarField.value = 'Rp. 0,00';
        }
    });
</script>


        </div>
        <div class="row col-md-12"><hr></div>
    <?php
    }
}
?>

</div>

<h3>Perlu Pembayaran Pemesanan</h3>
<hr>
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama Pemesan</th>
            <th>Tanggal Pesan</th>
            <th>Tanggal Digunakan</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php while($data = $q->fetch_object()){ ?>
        <tr <?php echo ($data->read == 0) ? 'style="background:#cce9f8 !important;"' : ''; ?>>
            <th scope="row"><?php echo $no++; ?></th>
            <td><?php echo htmlspecialchars($data->nama); ?></td>
            <td><?php echo substr($data->tanggal_pesan, 0, 10); ?></td>
            <td><?php echo $data->tanggal_digunakan; ?></td>
            <td>
                <a class="btn btn-sm btn-primary" href="pembayaran.php?act=bayar&id=<?php echo $data->id; ?>">Bayar</a>
                <a class="btn btn-sm btn-danger" href="pembayaran.php?act=delete&id=<?php echo $data->id; ?>" onclick="return confirm('Yakin ingin batalkan pesanan ini?')">Batalkan</a>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>

</div>

<?php include "layout/footer.php"; ?>
