<?php 
include "inc/config.php";
include "layout/header.php";

if(empty($_SESSION['cart'])){
    $_SESSION['cart'] = serialize([]);
}

if(!empty($_GET['produk_id']) && $_GET['act'] == 'beli'){
    $cart = unserialize($_SESSION['cart']);
    if(!is_array($cart)) $cart = [];

    $pid = (int)$_GET['produk_id'];
    $qty = 1; // Default beli 1 porsi dulu

    if(isset($_GET['update_cart'])){
        $new_qty = (int)$_GET['qty'];
        if($new_qty > 0){
            $cart[$pid] = $new_qty;
        } else {
            unset($cart[$pid]);
        }
    } elseif(isset($_GET['delete_cart'])){
        unset($cart[$pid]);
    } else {
        if(isset($cart[$pid])){
            $cart[$pid] += $qty;
        } else {
            $cart[$pid] = $qty;
        }
    }

    $_SESSION['cart'] = serialize($cart);
    redir($url.'keranjang.php');
    exit;
}
?>

<div class="col-md-9">
    <div class="row">
        <div class="col-md-12">
            <h2>Keranjang anda :</h2>
            <table class="table table-striped">
                <thead>
                    <tr style="background:#c3ebf8;font-weight:bold;">
                        <td>Produk</td>
                        <td>Details</td>
                        <td>QTY</td>
                        <td>Total</td>
                        <td>&nbsp;</td>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $total = 0;
                $cart = unserialize($_SESSION['cart']);
                if(!is_array($cart)) $cart = [];

                foreach($cart as $id => $qty){
                    $id = (int)$id;
                    $product_q = mysqli_query($koneksi, "SELECT * FROM produk WHERE id='$id'");
                    $product = mysqli_fetch_assoc($product_q);
                    if($product){
                        $t = $qty * $product['harga'];
                        $total += $t;
                ?>
                    <tr class="barang-shop">
                        <td><img src="<?= $url.'uploads/'.$product['gambar']; ?>" alt="img" width="120px"></td>
                        <td>
                            <h4><?= htmlspecialchars($product['nama']); ?></h4>
                            <div class="price">Rp <?= number_format($product['harga'], 2, ',', '.'); ?></div>
                        </td>
                        <td>
                            <form action="keranjang.php" method="GET"> 
                                <input type="hidden" name="update_cart" value="update">
                                <input type="hidden" name="act" value="beli">
                                <input type="hidden" name="produk_id" value="<?= $id; ?>">
                                <input class="form-control" type="number" name="qty" value="<?= $qty; ?>" min="1" onchange="this.form.submit()">
                            </form>
                        </td>
                        <td class="price"><?= number_format($t, 2, ',', '.'); ?></td>
                        <td>
                            <a href="keranjang.php?delete_cart=yes&&act=beli&&produk_id=<?= $id; ?>" title="Hapus">
                                <i class="glyphicon glyphicon-trash fa-2x"></i>
                            </a>
                        </td>
                    </tr>
                <?php }} ?>
                <tr style="background:#c3ebf8;font-weight:bold;">
                    <td colspan="3">SUB TOTAL</td>
                    <td><?= number_format($total, 2, ',', '.'); ?></td>
                    <td>&nbsp;</td>
                </tr>
                </tbody>
            </table>
        </div>
        <div style="float:right;" class="col-sm-6 col-md-6">
            <h4><b>Total Keranjang Belanja</b></h4>
            <table class="table table-bordered">
                <tr>
                    <td style="background:#fafafa;"><b>Total</b></td>
                    <td><b>Rp <?= number_format($total, 2, ',', '.'); ?></b></td>
                </tr>
            </table>
            <form action="<?= $url.'order.php' ?>" method="POST"> 
                <input type="hidden" name="okay" value="cart">
                <button <?= ($total == 0)? 'disabled' : '' ?> type="submit" class="btn btn-primary">Selesai Belanja &raquo;</button>
            </form>
        </div>
    </div> 
</div>     

<?php include "layout/footer.php"; ?>
